import React from "react";

const PropertyImg = () => {
  return <div></div>;
};

export default PropertyImg;
